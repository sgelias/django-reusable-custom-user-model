from django.apps import AppConfig


class AccountOwnerConfig(AppConfig):
    name = 'account_owner'
